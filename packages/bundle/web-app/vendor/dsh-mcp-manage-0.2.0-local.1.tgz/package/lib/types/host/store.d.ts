/**
 * MCP server record store — the durable half of MCP management.
 *
 * Records live in `$DSH_HOME/mcp-manage/servers.json` (outside every session
 * workspace) and are mutated only through this module: load, save, mint ids,
 * and validate definitions. The runtime half (loading live
 * `@deepseek-ai/dsh-mcp-client` instances) lives in ./manager.ts.
 *
 * @module dsh-mcp-manage/host/store
 */
import type { McpExternalOverride, McpServerDef, McpServerId } from '../types.ts';
/** The whole durable store. */
export interface StoreShape {
    servers: McpServerDef[];
    overrides: Record<string, McpExternalOverride>;
}
/** An empty store. */
export declare function emptyStore(): StoreShape;
/**
 * The override a composition row carries across an enable/disable toggle or
 * a restore. A runtime config edit (`config`, with the row's original loader
 * `options` kept for revert) must survive both directions of the toggle —
 * disabling keeps it dormant, re-enabling brings it back as `modified`.
 * A row with no edit keeps the historical bare shapes (`disabled` toggle /
 * deleted on enable), so nothing changes for rows the user never edited.
 */
export declare function carriedOverride(prior: McpExternalOverride | undefined, state: 'disabled' | 'modified'): McpExternalOverride | undefined;
/** Resolve the plugin's storage directory under the DSH home. */
export declare function storeDir(): string;
/** Absolute path of the servers document. */
export declare function storePath(): string;
/** Mint a record id that is unique against `existing`. */
export declare function mintId(existing: readonly McpServerId[]): McpServerId;
/**
 * Load the store; a missing document is an empty store (first use), while an
 * unreadable or malformed one throws loud — a present file that cannot parse
 * is a corruption the operator must see, never silently reset.
 */
export declare function loadStore(): Promise<StoreShape>;
/** Persist the store atomically (tmp file + rename), creating the directory. */
export declare function saveStore(store: StoreShape): Promise<void>;
/**
 * Validate one definition; returns the first problem or undefined.
 * Mirrors the generic mcp-client config contract without importing it.
 */
export declare function validate(server: Partial<McpServerDef>): string | undefined;
/** Whether the store file exists (first-run detection for the UI). */
export declare function storeExists(): boolean;
