/**
 * dsh-mcp-manage — host half: the MCP management backend.
 *
 * One route family under /api/dsh-mcp-manage that lists every installed MCP
 * tool, and adds / edits / deletes / enables / disables MCP servers at
 * runtime. Definitions persist in `$DSH_HOME/mcp-manage/servers.json` (the
 * record store); every enabled record is loaded as a live
 * `@deepseek-ai/dsh-mcp-client` child instance of this plugin (the runtime
 * manager), so a change takes effect immediately and survives a host restart.
 * Composition-configured mcp-client rows (cordis.yml / patch layers) are
 * equally manageable: enable/disable and remove run through the Loader, with
 * the override persisted here and re-applied as rows appear at boot.
 * The browser half (./client) renders the 设置 → MCP 管理 page.
 *
 * @module dsh-mcp-manage
 */
import type { Context } from '@deepseek-ai/cordis';
/** Route prefix for this plugin's JSON operations. */
export declare const ROUTE_PREFIX = "/api/dsh-mcp-manage";
export declare const inject: string[];
/**
 * Plugin entry: restore every enabled record as a live instance, keep the
 * persisted composition overrides enforced as loader rows appear, then serve
 * the management route family. Disposal (host teardown or plugin removal)
 * disposes every instance through the fiber effect scope.
 * @param ctx - the plugin context (webServer + tools injected).
 */
export declare function apply(ctx: Context): Promise<void>;
