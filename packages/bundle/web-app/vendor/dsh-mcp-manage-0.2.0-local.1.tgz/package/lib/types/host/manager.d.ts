/**
 * MCP runtime manager — the live half of MCP management.
 *
 * Loads one `@deepseek-ai/dsh-mcp-client` plugin instance per enabled record
 * as an effect-scoped child of this plugin's fiber, tracks each instance's
 * activation state, and enumerates the MCP tools visible on `ctx.tools`.
 * Combined with the record store this gives add / edit / delete / enable /
 * disable at runtime, with no host restart.
 *
 * @module dsh-mcp-manage/host/manager
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpExternalOverride, McpExternalServer, McpServerDef, McpServerView } from '../types.ts';
/**
 * Per-plugin manager. One instance per host fiber; disposal of the owning
 * plugin disposes every live instance through the fiber effect scope.
 */
export declare class McpManager {
    private readonly ctx;
    /** Loaded instances keyed by record id. */
    private readonly live;
    /** Last activation failure text per record id (survives instance disposal). */
    private readonly failures;
    /** The mcp-client module, imported once per manager. */
    private module;
    /** In-flight import so concurrent starts share one attempt. */
    private importing;
    /**
     * Set while an explicit mutation (restore) is settling. The loader emits
     * `entry-init` re-entrantly inside `group.create`, and the enforcement hook
     * must not read a stale override store and undo the very row being built.
     */
    private mutating;
    /** Run `task` with enforcement suspended (explicit mutations own ordering). */
    withMutation<T>(task: () => Promise<T>): Promise<T>;
    constructor(ctx: Context);
    /**
     * Import the generic mcp-client. Resolution order mirrors the loader: the
     * owning entry tree first (bare names resolve against the same base as
     * every composed row — the dsh installation), then a plain import (a
     * profile-local dependency install).
     */
    private resolveModule;
    /**
     * Translate one record into the generic client's config shape. Public:
     * the external-config edit route maps a client-submitted definition
     * through the exact same mapping the boot path uses, so a config this
     * manager would load itself is by construction acceptable to the row.
     */
    toConfig(def: McpServerDef): Record<string, unknown>;
    /**
     * Load one enabled record as a live instance. The fork is awaited so the
     * caller's HTTP response reports the settled activation: `active` on
     * success, `error` (already disposed) on rejection.
     */
    start(def: McpServerDef): Promise<void>;
    /** Clear one record's remembered failure (after a successful edit). */
    clearFailure(id: string): void;
    /** Last activation failure text for a record, if any. */
    failureOf(id: string): string | undefined;
    /** Dispose one live instance (idempotent; missing ids are a no-op). */
    stop(id: string): Promise<void>;
    private disposeInstance;
    /** Live `serverName`s this manager owns (collision checks on add/edit). */
    activeServerNames(): Set<string>;
    /** The record a live instance was loaded from (status views). */
    instanceDef(id: string): McpServerDef | undefined;
    /** MCP tools visible on `ctx.tools`, grouped by server namespace. */
    toolsByServer(): Map<string, string[]>;
    /**
     * Project the record list into view rows: managed state plus discovered
     * tools, and the composition-configured servers this plugin does not own
     * (with their persisted override state).
     */
    views(servers: readonly McpServerDef[], overrides?: Readonly<Record<string, McpExternalOverride>>): {
        managed: McpServerView[];
        external: McpExternalServer[];
    };
    /** Structural face of the vendored Loader service (4.0.1 typings omit it). */
    private loaderFace;
    /**
     * Every composition mcp-client row currently in the loader tree.
     * Entries created by this manager's own instances carry no loader row.
     */
    externalEntries(): Array<{
        entryId: string;
        serverName: string;
        disabled: boolean;
        config?: Record<string, unknown>;
    }>;
    /**
     * Disable (or re-enable) one composition row. Runs through the entry's own
     * `update`, which mounts/disposes the fiber WITHOUT persisting to the
     * composition file — this plugin's store is the single persistence for
     * overrides, so a user-patch HMR reload that resets rows is re-enforced
     * from here instead of fighting a materialized write-back.
     */
    setExternalEnabled(entryId: string, enabled: boolean): Promise<void>;
    /** Clone one composition row's current loader options (pre-edit snapshot). */
    cloneExternalOptions(entryId: string): Record<string, unknown>;
    /**
     * Replace one composition row's mcp-client config and restart it. Like the
     * enable toggle this does not touch the composition file — the caller
     * persists the edited config as a `modified` override in the record store.
     */
    updateExternalConfig(entryId: string, config: Record<string, unknown>): Promise<void>;
    /** Revert one composition row to its original options (undo a config edit). */
    revertExternal(entryId: string, options: Record<string, unknown>): Promise<void>;
    /** Remove one composition row, returning its options for a later restore. */
    removeExternal(entryId: string): Promise<Record<string, unknown>>;
    /** Re-create a previously removed composition row in its original tree. */
    restoreExternal(options: Record<string, unknown>): Promise<string>;
    /** Resolve one composition row or throw the loader's own not-found error. */
    private resolveExternal;
    /**
     * Idempotently apply persisted overrides against the live tree. Converging
     * by observation (is the row already in the desired state?) keeps repeated
     * calls — boot entry-init events, config reloads, list reads — free of
     * side effects.
     */
    enforceOverrides(overrides: Readonly<Record<string, McpExternalOverride>>): Promise<void>;
    /** Dispose every live instance (plugin teardown). */
    disposeAll(): Promise<void>;
}
