/**
 * Browser-side API client for the /api/dsh-mcp-manage route family.
 * Plain fetch, same origin — the only data path the MCP page uses.
 *
 * @module dsh-mcp-manage/client/api
 */
import type { McpExternalServer, McpServerDef, McpServerView } from '../types.ts';
/** Route prefix the host half serves. */
export declare const ROUTE_PREFIX = "/api/dsh-mcp-manage";
/** Full surface read (GET /servers). */
export interface ServersSnapshot {
    servers: McpServerView[];
    external: McpExternalServer[];
    storePath: string;
}
/** Result of one mutation (add / edit / toggle): the settled row plus the
 * activation failure text when the live instance could not start. */
export interface MutationResult {
    server?: McpServerView;
    startError?: string;
}
/** Raw JSON envelope every route answers with. */
interface Envelope {
    ok: boolean;
    error?: string;
    startError?: string;
}
/** Read every managed server and composition-owned MCP tool group. */
export declare function listServers(): Promise<ServersSnapshot>;
/** Add one server definition; loads it immediately when enabled. */
export declare function addServer(server: McpServerDef): Promise<MutationResult>;
/** Replace one server definition; restarts its live instance when enabled. */
export declare function updateServer(id: string, server: McpServerDef): Promise<MutationResult>;
/** Delete one server definition and dispose its live instance. */
export declare function deleteServer(id: string): Promise<void>;
/** Enable (load now) or disable (dispose) one server. */
export declare function setServerEnabled(id: string, enabled: boolean): Promise<MutationResult>;
/** Enable (or disable) one composition-provided MCP row through the loader. */
export declare function setExternalEnabled(entryId: string, enabled: boolean): Promise<McpExternalServer[]>;
/** Remove one composition-provided MCP row (restorable). */
export declare function removeExternal(entryId: string): Promise<McpExternalServer[]>;
/** Undo a remove/disable override on one composition-provided row. */
export declare function restoreExternal(entryId: string): Promise<McpExternalServer[]>;
/** Replace one composition row's mcp-client config (runtime edit). */
export declare function updateExternalConfig(entryId: string, server: McpServerDef): Promise<McpExternalServer[]>;
/** Revert one composition row's runtime config edit to its original options. */
export declare function revertExternalConfig(entryId: string): Promise<McpExternalServer[]>;
export type { Envelope };
