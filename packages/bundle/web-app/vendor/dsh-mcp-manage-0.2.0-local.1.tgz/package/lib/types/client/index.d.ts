/**
 * MCP management client plugin — registers the settings page
 * (设置 → MCP 管理) into `settings.section`. The page talks to the host
 * route family under /api/dsh-mcp-manage served by the node half.
 *
 * @module dsh-mcp-manage/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        'settings.section': {
            kind: 'list';
            scope: 'root';
            owner: {
                close: () => void;
            };
        };
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Register the MCP-management settings page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
